# Jefvantongerloo.aos release notes

## [0.1.0] - Unreleased

### Added

- Module `device_info` - Returns device information dictionary
- Plugin `cliconf.aos`
- Plugin `terminal.aos`
