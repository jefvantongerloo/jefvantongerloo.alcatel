# jefvantongerloo.aos.device_info

> Module to collect device info from Alcatel-Lucent Enterprise Omniswitch devices.

Version added: 0.1.0

## Synopsis

## Parameters

## Notes

## Examples

## Return Values